# VaultWeather

A little weather station inspired by Fallout. It fetches local weather over WiFi and plays different animations throughout the day, like drinking coffee in the morning and yawning at night.

This was only my second build like this, so it’s a bit rough around the edges. I figured out the layout as I went. The round brass rod forms the exposed frame and carries some connections. I rerouted four connections with copper wire after running into a few shorts.

## Hardware

ESP32 C3 SuperMini  
2 inch ST7789 SPI TFT (240 × 320)  
3.7 V LiPo battery  
USB C LiPo charging module with 5 V boost  
Power switch  
Round brass rod and four copper wires

## Getting started

See [START_HERE.txt](START_HERE.txt) for the Arduino settings, display wiring, location settings and first boot WiFi setup. London is only an example. Change the city and coordinates in the sketch’s config.h before uploading.

Weather data is provided by Open Meteo. No API key, weather sensor or SD card is needed. The sketch includes the artwork and animations.
