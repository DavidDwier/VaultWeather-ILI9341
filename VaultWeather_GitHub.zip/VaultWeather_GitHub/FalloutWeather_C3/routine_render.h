#pragma once
#include <stdint.h>
// Shared by firmware and the native preview/check program. RGB565 arithmetic.
inline uint16_t blend565(uint16_t dst,uint16_t src,int a,int total=15) {
  int r=(((dst>>11)&31)*(total-a)+((src>>11)&31)*a)/total;
  int g=(((dst>>5)&63)*(total-a)+((src>>5)&63)*a)/total;
  int b=((dst&31)*(total-a)+(src&31)*a)/total;
  return uint16_t((r<<11)|(g<<5)|b);
}
inline bool phosphor(uint16_t p) {return ((p>>5)&63)>26 && ((p>>11)&31)<12;}
inline bool weatherGlyph(int art,int x,int y) {
  const uint8_t icons[10][4]={{91,49,48,46},{93,51,46,46},{95,53,65,54},
    {98,52,62,55},{71,51,100,47},{94,48,55,31},{81,69,40,27},
    {0,0,0,0},{51,63,90,42},{0,0,0,0}};
  const uint8_t* b=icons[art];
  return x>=b[0] && x<b[0]+b[2] && y>=b[1] && y<b[1]+b[3];
}
template<class Pixel> uint16_t crtField(Pixel pixel,int x,int y,int left,int right) {
  // The empty right half of this CRT is the matching mirrored screen surface.
  // Read the same scanline with mirrored horizontal shading (no repeated tile).
  int lx=left-2,rx=right+2;
  if(lx<40)lx=40;if(rx>172)rx=172;
  uint16_t m=pixel(320-x,y),ol=pixel(lx,y),orr=pixel(rx,y);
  uint16_t ml=pixel(320-lx,y),mr=pixel(320-rx,y);
  float u=float(x-lx)/(rx-lx);
  int out=0;
  for(int k=0;k<3;k++) {
    int shift=k==0?11:(k==1?5:0),mask=k==1?63:31;
    int dl=int((ol>>shift)&mask)-int((ml>>shift)&mask);
    int dr=int((orr>>shift)&mask)-int((mr>>shift)&mask);
    int value=int(((m>>shift)&mask)+dl*(1-u)+dr*u+0.5f);
    if(value<0)value=0;if(value>mask)value=mask;out|=value<<shift;
  }
  return uint16_t(out);
}
template<class Pixel> void routineBackdrop(Pixel pixel,int art,uint16_t* dst) {
  const uint8_t firstY[10]={100,101,96,96,95,79,98,74,105,96};
  for(int sy=0;sy<132;sy++) {
    int y=sy+39,left=320,right=-1;
    for(int x=44;x<168;x++) dst[sy*124+x-44]=pixel(x,y);
    if(y+2<firstY[art])continue;
    for(int yy=y-2;yy<=y+2;yy++) for(int x=44;x<166;x++) {
      if(yy>=firstY[art] && !weatherGlyph(art,x,yy) && phosphor(pixel(x,yy))) {
        if(x<left)left=x;if(x>right)right=x;
      }
    }
    if(right<left)continue;
    left-=3;right+=3;if(left<44)left=44;if(right>167)right=167;
    for(int x=left;x<=right;x++) {
      if(weatherGlyph(art,x,y))continue;
      dst[sy*124+x-44]=crtField(pixel,x,y,left,right);
    }
  }
}

template<class Read> void routineSprite(Read read,int art,uint16_t* dst) {
  // Match each source scene's phosphor brightness; preserve shaded outlines
  // and alpha edges rather than painting a solid green silhouette.
  const uint8_t peak[10]={225,239,238,241,241,236,231,240,237,225};
  for(int y=0;y<112;y++) for(int x=0;x<128;x++) {
    int sx=x+32-44,sy=y+60-39;
    if(sx<0 || sx>=124 || sy<0 || sy>=132)continue;
    uint8_t value=read(y*128+x);
    int alpha=value>>4,shade=value&15;
    if(!alpha)continue;
    int green=(shade*peak[art]+7)/15;
    if((y+60)%3==0)green=green*95/100;
    uint16_t color=uint16_t((green>>2)<<5);
    uint16_t *dest=dst+sy*124+sx;
    *dest=blend565(*dest,color,alpha);
  }
}
