#pragma once
#include <stdint.h>
// IDs retain morning=1/evening=2 for previous assets; afternoon=3/night=4.
inline uint8_t routineKind(int hour) {
  if(hour>=6 && hour<12)return 1;
  if(hour>=12 && hour<18)return 3;
  if(hour>=18 && hour<22)return 2;
  return 4;
}
inline uint32_t routineCycleMs(uint8_t kind) {
  return kind==1?6000:(kind==2?4500:(kind==3?5600:(kind==4?6000:0)));
}
inline int routineFrame(uint8_t kind,uint32_t elapsed) {
  uint32_t cycle=routineCycleMs(kind);
  if(!cycle || elapsed>=cycle*2)return -1;
  elapsed%=cycle; // Two complete plays, then restore the normal weather scene.
  static const uint16_t morningEnds[]={900,2200,2900,3600,5000,6000};
  static const uint16_t eveningEnds[]={800,1200,1700,2200,3000,3500,4500};
  static const uint16_t afternoonEnds[]={800,1600,2400,3000,3700,4300,4900,5600};
  static const uint8_t afternoonOrder[]={12,13,14,12,15,16,15,17};
  static const uint16_t nightEnds[]={900,1700,2500,3900,4800,6000};
  static const uint8_t eveningOrder[]={6,7,8,9,10,9,11};
  if(kind==1){for(int i=0;i<6;i++)if(elapsed<morningEnds[i])return i;}
  if(kind==2){for(int i=0;i<7;i++)if(elapsed<eveningEnds[i])return eveningOrder[i];}
  if(kind==3){for(int i=0;i<8;i++)if(elapsed<afternoonEnds[i])return afternoonOrder[i];}
  if(kind==4){for(int i=0;i<6;i++)if(elapsed<nightEnds[i])return 18+i;}
  return -1;
}
