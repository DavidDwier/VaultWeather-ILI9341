#pragma once
#include <stdint.h>
#include <stdlib.h>
#include <math.h>

// Strictly inside the LEFT glass, in every supplied scene. The right panel
// and bezel are never part of an animation transfer. Only one tile is in RAM.
constexpr int EFFECT_X=34,EFFECT_Y=34,EFFECT_W=138,EFFECT_H=174,EFFECT_TILE_H=12;
inline uint16_t effectBlend(uint16_t base,uint16_t ink,int alpha) {
  int inv=255-alpha;
  int r=(((base>>11)&31)*inv+((ink>>11)&31)*alpha+127)/255;
  int g=(((base>>5)&63)*inv+((ink>>5)&63)*alpha+127)/255;
  int b=((base&31)*inv+(ink&31)*alpha+127)/255;
  return uint16_t((r<<11)|(g<<5)|b);
}
struct EffectTile {
  uint16_t *pixels;int top,rows;
  void dot(int x,int y,uint16_t color,int alpha=120) {
    if(x<0 || x>=EFFECT_W || y<top || y>=top+rows) return;
    uint16_t &p=pixels[(y-top)*EFFECT_W+x];p=effectBlend(p,color,alpha);
  }
  void line(int x,int y,int x2,int y2,uint16_t color,int alpha=120) {
    int dx=abs(x2-x),sx=x<x2?1:-1,dy=-abs(y2-y),sy=y<y2?1:-1,err=dx+dy;
    for(;;) {dot(x,y,color,alpha);if(x==x2 && y==y2) break;
      int e=2*err;if(e>=dy) {err+=dy;x+=sx;}if(e<=dx) {err+=dx;y+=sy;}}
  }
  void star(int x,int y,int r,int alpha) {
    line(x-r,y,x+r,y,0xaff5,alpha);line(x,y-r,x,y+r,0xaff5,alpha);
  }
};
inline void drawWeatherEffects(uint16_t *pixels,int top,int rows,uint8_t index,uint32_t ms) {
  EffectTile c{pixels,top,rows};
  const uint32_t tick=ms/150;
  if(index==0) { // Small ray glints; the technician and sun artwork stay still.
    const int xs[]={30,107,119},ys[]={30,18,61};
    for(int i=0;i<3;i++) {
      int phase=(tick+i*9)%32,alpha=phase<16?phase*8:(31-phase)*8;
      c.star(xs[i],ys[i],1,alpha);
    }
  } else if(index==1) {
    const int xs[]={16,49,101,110,90},ys[]={21,5,14,43,67};
    for(int i=0;i<5;i++) {
      int phase=(tick+i*7)%40,alpha=phase<20?phase*7:(39-phase)*7;
      c.star(xs[i],ys[i],1,alpha);
    }
  } else if(index>=2 && index<=4) {
    // Broad translucent cloud shadows drift across the sky only. Never move
    // sampled background pixels: original cloud edges and pose stay intact.
    for(int y=top;y<top+rows && y<77;y++) for(int x=0;x<EFFECT_W;x++) {
      float phase=(x-float((ms/90)%700))*0.055f+y*0.025f;
      float band=sinf(phase)+0.45f*sinf(phase*1.7f+1.3f);
      int alpha=band>0?int(band*(index==4?19:13)):0;
      c.dot(x,y,index==4?0x0020:0x0121,alpha);
    }
  } else if(index==5 || index==6 || index==8) {
    bool light=index==5;int count=light?6:14;
    for(int i=0;i<count;i++) {
      int y=(tick*(light?2:5)+i*23)%EFFECT_H;
      int x=8+(i*37+tick/5)%(EFFECT_W-16);
      c.line(x,y,x-(light?1:3),y+(light?3:8),0x87f0,light?95:120);
    }
    if(index==6) { // Low puddle ripples beside the umbrella.
      for(int i=0;i<2;i++) {
        int radius=2+(tick+i*8)%12,cy=161+i*6,cx=102+i*16;
        for(int a=0;a<24;a++) {
          float angle=a*0.2617994f;
          c.dot(cx+int(cosf(angle)*radius),cy+int(sinf(angle)*(radius/3+1)),0x6f0c,110-radius*5);
        }
      }
    }
    if(index==8) {
      // Brief local fork, never a full-screen or panel flash.
      uint32_t phase=ms%7900;
      if(phase<150 || (phase>=300 && phase<450)) {
        c.line(105,9,94,31,0xcff7,170);c.line(94,31,103,28,0xcff7,170);
        c.line(103,28,89,54,0xcff7,170);c.line(97,34,112,42,0x8ff0,110);
      }
    }
  } else if(index==7) {
    for(int i=0;i<10;i++) {
      int y=(tick+i*19)%EFFECT_H;
      int drift=int(4*sinf(float(tick%360)*0.09f+i));
      int x=8+(i*29+drift+EFFECT_W)%(EFFECT_W-16);
      c.star(x,y,i%3==0?2:1,105);
    }
  } else if(index==9) {
    // Feathered ribbons, transparent enough to retain the supplied fog pose.
    for(int y=top;y<top+rows;y++) for(int x=0;x<EFFECT_W;x++) {
      int alpha=0;
      for(int i=0;i<4;i++) {
        float center=21+i*39+5*sinf(x*0.04f-float((ms/100)%630)*0.035f+i);
        float distance=fabsf(y-center);
        if(distance<5) alpha+=int((5-distance)*6);
      }
      if(alpha) c.dot(x,y,0x4f28,alpha);
    }
  }
}
