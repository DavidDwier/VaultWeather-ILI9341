/* VaultWeather GitHub edition - ESP32-C3 SuperMini + ST7789.
   Supplied static artwork, weather-only effects. All artwork is in flash. */
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <time.h>
#include "config.h"
#include "weather_logic.h"
#include "weather_assets.h"
#include "weather_ca.h"
#include "wifi_retry.h"
#include "weather_render.h"
#include "weather_effects.h"

Adafruit_ST7789 tft(&SPI, TFT_CS, TFT_DC, TFT_RST);
// Stream complete restored tiles: low RAM use, no clear-then-redraw flicker.
GFXcanvas16 scene(EFFECT_W,EFFECT_TILE_H), panel(PANEL_W,PANEL_H);
WebServer server(80);
DNSServer dns;
Preferences prefs;
struct Weather { float temp=0, feels=0, wind=0; int humidity=0, code=0; bool day=true; String stamp; } weather;
bool haveWeather=false, fetchFailed=false, portal=false, applyWiFi=false;
bool prefsReady=false, portalRoutesReady=false, wasWiFiConnected=false;
uint32_t applyAfter=0, connectedAt=0;
WifiRetry wifiRetry;
String savedSSID, savedPass;
uint32_t nextFetch=0, lastFrame=0, lastPanel=0, lastDemo=0, fetchedAt=0;
uint8_t artIndex=4;
const uint16_t GREEN=0x07E0, DIM=0x04E0;
const char PAGE[] PROGMEM = R"HTML(<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Vault Weather</title><style>body{background:#07180d;color:#6dff80;font:18px monospace;max-width:420px;margin:35px auto;padding:20px}input,button{box-sizing:border-box;width:100%;padding:14px;margin:8px 0;background:#102a17;color:#8fff98;border:1px solid #49af55}small{font-size:13px}</style></head><body><h2>VAULT WEATHER</h2><p>Connect your weather station to your home 2.4 GHz Wi-Fi.</p><form method="POST" action="/save"><label>Wi-Fi name</label><input name="ssid" maxlength="32" required autocomplete="off"><label>Password</label><input name="pass" type="password" maxlength="63"><button>Save and connect</button></form><small>%WEATHER_CITY% weather &middot; Open-Meteo<br>Open networks can use an empty password.</small></body></html>)HTML";

uint16_t artPixel(int x,int y) {
  return weatherArtPixel(artIndex,x,y);
}
void drawBase() {
  uint16_t row[320];
  for(int y=0;y<240;y++) {
    for(int x=0;x<320;x++) row[x]=artPixel(x,y);
    tft.drawRGBBitmap(0,y,row,320,1);
  }
}
void drawAnimation(uint32_t ms) {
  // Paused weather uses the same restored static image, without trails.
  uint16_t *pixels=scene.getBuffer();
  for(int top=0;top<EFFECT_H;top+=EFFECT_TILE_H) {
    int rows=min(EFFECT_TILE_H,EFFECT_H-top);
    for(int y=0;y<rows;y++) for(int x=0;x<EFFECT_W;x++)
      pixels[y*EFFECT_W+x]=artPixel(EFFECT_X+x,EFFECT_Y+top+y);
    if(ANIMATION_ENABLED && haveWeather)
      drawWeatherEffects(pixels,top,rows,artIndex,ms);
    tft.drawRGBBitmap(EFFECT_X,EFFECT_Y+top,pixels,EFFECT_W,rows);
  }
}
void drawPanel() {
  uint16_t *pixels=panel.getBuffer();
  for(int y=0;y<PANEL_H;y++) for(int x=0;x<PANEL_W;x++)
    pixels[y*PANEL_W+x]=artPixel(PANEL_X+x,PANEL_Y+y);
  struct tm local; char clockText[10]="--:--";
  if(getLocalTime(&local,0)) strftime(clockText,sizeof(clockText),"%H:%M",&local);
  String status, data;
  if(DEMO_MODE) {
    char demo[18];snprintf(demo,sizeof(demo),"DEMO %02u/10",artIndex+1);
    status=demo;data="SAMPLE DATA";
  } else if(haveWeather) {
    if(WiFi.status()!=WL_CONNECTED) status="OFFLINE / LAST";
    else if(fetchFailed || millis()-fetchedAt>2*WEATHER_REFRESH_MS) status="STALE / RETRY";
    else status="LIVE / WI-FI OK";
    data="DATA "+weather.stamp.substring(11,16);
  } else if(WiFi.status()==WL_CONNECTED) {
    status="WI-FI OK";
    data=time(nullptr)<1700000000?"SYNCING CLOCK":(fetchFailed?"RETRYING API":"GETTING DATA");
  } else if(savedSSID.isEmpty()) {status="PHONE: JOIN";data="VaultWeather";}
  else {status="RECONNECTING";data="SAVED WI-FI";}
  PanelValues v{WEATHER_CITY,clockText,weatherLabel(weather.code,weather.day),
                status.c_str(),data.c_str(),haveWeather,weather.temp,weather.feels,
                weather.wind,weather.humidity};
  drawWeatherPanel(panel,v);
  if(!haveWeather && WiFi.status()!=WL_CONNECTED && savedSSID.isEmpty())
    panelText(panel,0,117,"192.168.4.1");
  tft.drawRGBBitmap(PANEL_X,PANEL_Y,pixels,PANEL_W,PANEL_H);
}
void setDemoScene(uint8_t index) {
  static const int codes[10]={0,0,2,2,3,53,63,73,95,45};
  artIndex=index;weather.code=codes[index];weather.day=index!=1 && index!=3;
  haveWeather=true;weather.temp=18;weather.feels=17.4;weather.wind=8;weather.humidity=65;
  drawBase();drawAnimation(millis());drawPanel();
}
bool validCredentials(const String &ssid,const String &pass) {
  return ssid.length()>0 && ssid.length()<=32 && pass.length()<=63 &&
         (pass.isEmpty() || pass.length()>=8);
}
bool saveCredentials(const String &ssid,const String &pass) {
  if(!prefsReady) prefsReady=prefs.begin("vaultweather",false);
  if(!prefsReady) {Serial.println("WiFi: preferences storage unavailable");return false;}
  // SSID/password are committed in a single NVS value, then read back.
  JsonDocument doc;doc["ssid"]=ssid;doc["pass"]=pass;
  String packed;serializeJson(doc,packed);
  if(prefs.putString("network",packed)==0 || prefs.getString("network","")!=packed) {
    Serial.println("WiFi: profile write/readback failed");return false;
  }
  Serial.println("WiFi: profile saved and verified (password not logged)");return true;
}
void loadCredentials() {
  // A nonempty config.h SSID deliberately takes priority as an optional fallback.
  if(String(WIFI_SSID).length()>0) {
    savedSSID=WIFI_SSID;savedPass=WIFI_PASSWORD;
    Serial.println("WiFi: using credentials from config.h");return;
  }
  prefsReady=prefs.begin("vaultweather",false);
  if(!prefsReady) {Serial.println("WiFi: unable to open preferences");return;}
  String packed=prefs.getString("network","");
  if(!packed.isEmpty()) {
    JsonDocument doc;
    if(!deserializeJson(doc,packed) && doc["ssid"].is<const char*>() && doc["pass"].is<const char*>()) {
      String ssid=doc["ssid"].as<String>(), pass=doc["pass"].as<String>();
      if(validCredentials(ssid,pass)) {
        savedSSID=ssid;savedPass=pass;Serial.println("WiFi: verified profile loaded from flash");return;
      }
    }
    Serial.println("WiFi: invalid new profile; checking legacy saved settings");
  }
  // Preserve the exact namespace/keys used by v1/v2, so updating needs no login.
  String ssid=prefs.getString("ssid",""), pass=prefs.getString("pass","");
  if(validCredentials(ssid,pass)) {
    savedSSID=ssid;savedPass=pass;
    Serial.println("WiFi: legacy profile loaded from flash");
    saveCredentials(savedSSID,savedPass); // Legacy keys are retained as a backup.
  } else Serial.println("WiFi: no saved profile; initial phone setup needed");
}
void configurePortalRoutes() {
  if(portalRoutesReady) return;
  server.on("/",HTTP_GET,[]{
    String city=WEATHER_CITY;
    city.replace("&","&amp;");
    city.replace("<","&lt;");
    city.replace(">","&gt;");
    String page=FPSTR(PAGE);
    page.replace("%WEATHER_CITY%",city);
    server.send(200,"text/html",page);
  });
  server.on("/save",HTTP_POST,[]{
    if(String(WIFI_SSID).length()>0) {
      server.send(409,"text/plain","Wi-Fi is configured in config.h. Edit that file to change networks.");return;
    }
    String ssid=server.arg("ssid"), pass=server.arg("pass");
    if(!validCredentials(ssid,pass)) {
      server.send(400,"text/plain","Check Wi-Fi name and password length.");return;
    }
    if(!saveCredentials(ssid,pass)) {
      server.send(500,"text/plain","Could not verify Wi-Fi storage. Retry or use config.h.");return;
    }
    savedSSID=ssid;savedPass=pass;
    server.send(200,"text/html","<meta name='viewport' content='width=device-width,initial-scale=1'><h2>Saved and verified.</h2><p>The station will reconnect automatically after power-off. It is now trying your home Wi-Fi. Check the station display for connection status.</p>");
    applyWiFi=true;applyAfter=millis()+750UL;
  });
  server.onNotFound([]{server.sendHeader("Location","http://192.168.4.1/",true);server.send(302,"text/plain","");});
  portalRoutesReady=true;
}
void startPortal() {
  if(portal) return;
  configurePortalRoutes();
  if(!WiFi.mode(WIFI_AP_STA) || !WiFi.softAP("VaultWeather",SETUP_AP_PASSWORD)) {
    Serial.println("WiFi: recovery hotspot could not start");return;
  }
  dns.start(53,"*",WiFi.softAPIP());server.begin();portal=true;
  Serial.println("Optional setup: VaultWeather / password vaultweather / http://192.168.4.1");
  if(!savedSSID.isEmpty()) Serial.println("WiFi: continuing saved-profile retries; re-entering password is NOT required");
}
void stopPortal() {
  if(!portal) return;
  server.stop();dns.stop();WiFi.softAPdisconnect(true);WiFi.mode(WIFI_STA);portal=false;
}
void startWiFiAttempt(bool restartRadio) {
  // Clear the failed attempt, without erasing either NVS profile or SDK AP data.
  WiFi.disconnect(false,false);
  if(restartRadio && (!portal || WiFi.softAPgetStationNum()==0)) {
    stopPortal();WiFi.mode(WIFI_OFF);delay(150);WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(false);
    Serial.println("WiFi: restarted radio after three failed attempts");
  } else delay(100); // Give the driver's disconnect event time to settle.
  Serial.printf("WiFi: connecting with saved credentials, attempt %lu\n",(unsigned long)wifiRetry.attempts());
  WiFi.begin(savedSSID.c_str(),savedPass.c_str());
}
// Network work runs on a separate task; the display stays animated during requests.
struct FetchResult { Weather value; bool ok; };
QueueHandle_t weatherQueue;
TaskHandle_t fetchTaskHandle=nullptr;
void fetchTask(void*) {
  { // Release TLS and String objects before deleting the FreeRTOS task.
  FetchResult result;
  result.ok=false;
  WiFiClientSecure client;
  // Validate the public endpoint certificate against the Mozilla root bundle.
  client.setCACertBundle(WEATHER_CA_BUNDLE, sizeof(WEATHER_CA_BUNDLE)); client.setTimeout(8); client.setHandshakeTimeout(8);
  HTTPClient http;
  String url="https://api.open-meteo.com/v1/forecast?latitude="+String(WEATHER_LAT,4)+"&longitude="+String(WEATHER_LON,4)+
    "&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m&wind_speed_unit=mph&timezone=auto&forecast_days=1";
  http.setConnectTimeout(8000); http.setTimeout(8000);
  if(time(nullptr)>1700000000 && http.begin(client,url)) {
    int code=http.GET();
    Serial.printf("Weather: HTTP result %d\n",code);
    if(code==200 && http.getSize()<16384) {
      JsonDocument doc;
      auto err=deserializeJson(doc,http.getString());
      if(err) Serial.printf("Weather: JSON error %s\n",err.c_str());
      JsonObject cur=doc["current"];
      if(!err && !cur.isNull() && cur["temperature_2m"].is<float>() &&
         cur["relative_humidity_2m"].is<int>() && cur["apparent_temperature"].is<float>() &&
         cur["wind_speed_10m"].is<float>() && cur["weather_code"].is<int>() &&
         cur["is_day"].is<int>() && cur["time"].is<const char*>()) {
        result.value.temp=cur["temperature_2m"].as<float>();
        result.value.feels=cur["apparent_temperature"].as<float>();
        result.value.wind=cur["wind_speed_10m"].as<float>();
        result.value.humidity=cur["relative_humidity_2m"].as<int>();
        result.value.code=cur["weather_code"].as<int>();
        result.value.day=cur["is_day"].as<int>()==1;
        result.value.stamp=cur["time"].as<String>();
        result.ok=isfinite(result.value.temp) && result.value.temp>=-80 && result.value.temp<=65 &&
          isfinite(result.value.feels) && isfinite(result.value.wind) && result.value.wind>=0 &&
          result.value.humidity>=0 && result.value.humidity<=100 && result.value.stamp.length()>=16;
      }
    }
    http.end();
  }
  // FreeRTOS queues copy raw bytes: use a pointer for the String-bearing result.
  FetchResult *owned=new FetchResult(result);
  if(xQueueSend(weatherQueue,&owned,0)!=pdTRUE) delete owned;
  }
  vTaskDelete(nullptr);
}
void beginFetch() {
  if(fetchTaskHandle || !weatherQueue) return;
  if(xTaskCreate(fetchTask,"weather",8192,nullptr,1,&fetchTaskHandle)!=pdPASS) {
    fetchTaskHandle=nullptr;fetchFailed=true;nextFetch=millis()+60000UL;
  }
}
void setup() {
  Serial.begin(115200);
  SPI.begin(TFT_SCLK,-1,TFT_MOSI,TFT_CS);
  tft.init(240,320); tft.setRotation(TFT_ROTATION);tft.invertDisplay(TFT_INVERT);tft.setSPISpeed(TFT_SPI_HZ);
  if(!scene.getBuffer() || !panel.getBuffer()) {tft.fillScreen(0);tft.setTextColor(GREEN);tft.setCursor(10,10);tft.print("LOW MEMORY");while(true)delay(1000);}
  drawBase(); drawPanel();
  weatherQueue=xQueueCreate(1,sizeof(FetchResult*));
  if(!weatherQueue) {Serial.println("Weather queue allocation failed");fetchFailed=true;}
  if(DEMO_MODE) {setDemoScene(0);return;}
  loadCredentials();
  WiFi.persistent(false); // Application preferences own the saved profile.
  WiFi.mode(WIFI_STA);WiFi.setAutoReconnect(false);
  WiFi.onEvent([](WiFiEvent_t,WiFiEventInfo_t info){
    Serial.printf("WiFi: disconnect reason %u\n",info.wifi_sta_disconnected.reason);
  },ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
  wifiRetry.reset(millis());
  if(savedSSID.isEmpty()) startPortal();
}
void loop() {
  uint32_t now=millis();
  if(DEMO_MODE) {
    if(now-lastDemo>=8000UL) {lastDemo=now;setDemoScene((artIndex+1)%10);}
  } else {
    if(portal) {dns.processNextRequest();server.handleClient();}
    if(applyWiFi && (int32_t)(now-applyAfter)>=0 && !fetchTaskHandle) {
      applyWiFi=false;WiFi.disconnect(false,false);delay(100);wasWiFiConnected=false;
      wifiRetry.reset(now);nextFetch=0;
    }
    bool connected=WiFi.status()==WL_CONNECTED;
    WifiRetryAction action=wifiRetry.tick(now,connected,!savedSSID.isEmpty(),fetchTaskHandle!=nullptr || applyWiFi);
    if(action==WifiRetryAction::Disconnect) {
      Serial.println("WiFi: attempt timed out; clearing state before retry");WiFi.disconnect(false,false);
    } else if(action==WifiRetryAction::Begin || action==WifiRetryAction::RestartRadio) {
      startWiFiAttempt(action==WifiRetryAction::RestartRadio);
      if(wifiRetry.failures()>=3) startPortal(); // Optional recovery, retries continue.
    }
    if(connected) {
      if(!wasWiFiConnected) {
        connectedAt=now;nextFetch=0;
        Serial.print("WiFi: connected, IP ");Serial.println(WiFi.localIP());
        configTzTime(LOCAL_TZ,"pool.ntp.org","time.nist.gov");
      }
      if(portal && !applyWiFi && now-connectedAt>=5000UL) stopPortal();
      // HTTPS needs correct time. Don't label an NTP wait as Wi-Fi failure.
      if(time(nullptr)>1700000000 && !fetchTaskHandle && (nextFetch==0 || (int32_t)(now-nextFetch)>=0)) {
        nextFetch=now+WEATHER_REFRESH_MS;beginFetch();
      }
    }
    wasWiFiConnected=connected;
    FetchResult *r=nullptr;
    if(weatherQueue && xQueueReceive(weatherQueue,&r,0)==pdTRUE) {
      fetchTaskHandle=nullptr;
      if(r->ok) {
        weather=r->value;haveWeather=true;fetchFailed=false;fetchedAt=now;
        uint8_t next=weatherScene(weather.code,weather.day);
        if(next!=artIndex) {artIndex=next;drawBase();drawAnimation(now);}
        Serial.printf("Weather: %.1f C code=%d scene=%u heap=%lu\n",weather.temp,weather.code,artIndex+1,(unsigned long)ESP.getFreeHeap());
      } else {fetchFailed=true;nextFetch=now+60000UL;Serial.println("Weather request failed; keeping last reading.");}
      delete r;drawPanel();
    }
  }
  if(now-lastFrame>=150UL) {lastFrame=now;drawAnimation(now);}
  if(now-lastPanel>=1000UL) {lastPanel=now;drawPanel();}
  delay(2);
}
