#pragma once
#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>

constexpr int PANEL_X=183, PANEL_Y=34, PANEL_W=105, PANEL_H=181;
constexpr uint16_t PANEL_GREEN=0x9ff2, PANEL_DIM=0x4da9;
struct PanelValues {
  const char *city,*clock,*condition,*status,*data;
  bool ready;
  float temp,feels,wind;
  int humidity;
};
template<class Canvas>
void panelText(Canvas &c,int x,int y,const char *s,uint8_t size=1,uint16_t color=PANEL_GREEN) {
  c.setTextWrap(false);c.setTextSize(size);c.setTextColor(color);c.setCursor(x,y);c.print(s);
}
// Preserve condition labels verbatim, wrapping at spaces if needed. City is
// the only shortened field; its full value remains in config and the portal.
template<class Canvas>
void panelLabel(Canvas &c,const char *s,int y) {
  constexpr int cols=PANEL_W/6;
  while(*s) {
    int count=0;while(s[count] && count<cols) ++count;
    if(s[count]) {
      int space=count;while(space>0 && s[space]!=' ') --space;
      if(space>0) count=space;
    }
    char line[cols+1];
    for(int i=0;i<count;i++) line[i]=s[i];
    line[count]=0;
    panelText(c,0,y,line);s+=count;while(*s==' ') ++s;
    y+=9;if(y>87) break;
  }
}
template<class Canvas>
void drawWeatherPanel(Canvas &c,const PanelValues &v) {
  char text[40],city[18];size_t n=0;
  while(v.city[n] && n<17) {city[n]=toupper((unsigned char)v.city[n]);++n;}
  city[n]=0;if(v.city[n]) {city[14]='.';city[15]='.';city[16]='.';}
  panelText(c,0,0,city);
  panelText(c,0,16,v.clock,2);
  if(v.ready) {
    snprintf(text,sizeof(text),"%d",int(lroundf(v.temp)));
    panelText(c,0,43,text,3);
    int len=0;while(text[len]) ++len;
    const int end=len*18;
    c.drawCircle(end+4,46,2,PANEL_GREEN);panelText(c,end+10,43,"C",2);
    panelLabel(c,v.condition,76);
    snprintf(text,sizeof(text),"FEELS %.1f C",double(v.feels));panelText(c,0,96,text);
    snprintf(text,sizeof(text),"HUM %d%%",v.humidity);panelText(c,0,110,text);
    snprintf(text,sizeof(text),"WIND %.0f MPH",double(v.wind));panelText(c,0,124,text);
  } else {
    panelText(c,0,54,"WAITING FOR");panelText(c,0,66,"WEATHER DATA");
  }
  panelText(c,0,143,v.status,1,PANEL_DIM);
  panelText(c,0,155,v.data,1,PANEL_DIM);
  panelText(c,0,173,"OPEN-METEO",1,PANEL_DIM);
}
