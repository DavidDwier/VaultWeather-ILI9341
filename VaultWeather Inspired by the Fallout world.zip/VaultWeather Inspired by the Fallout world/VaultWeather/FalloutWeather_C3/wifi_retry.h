#pragma once
#include <stdint.h>

// One owner for reconnect timing; the Arduino core's automatic retries are off.
enum class WifiRetryAction { None, Begin, Disconnect, RestartRadio };
class WifiRetry {
public:
  void reset(uint32_t now) {
    online_=false; trying_=false; failures_=0; attempts_=0; deadline_=now;
  }
  WifiRetryAction tick(uint32_t now, bool connected, bool haveCredentials, bool networkBusy) {
    if(connected) {online_=true; trying_=false; failures_=0; return WifiRetryAction::None;}
    if(!haveCredentials) return WifiRetryAction::None;
    if(online_) {online_=false; trying_=false; deadline_=now+1000UL;}
    if(networkBusy || int32_t(now-deadline_)<0) return WifiRetryAction::None;
    if(trying_) {
      trying_=false; ++failures_; deadline_=now+5000UL;
      return WifiRetryAction::Disconnect;
    }
    trying_=true; ++attempts_; deadline_=now+25000UL;
    return failures_>0 && failures_%3==0 ? WifiRetryAction::RestartRadio : WifiRetryAction::Begin;
  }
  uint32_t failures() const {return failures_;}
  uint32_t attempts() const {return attempts_;}
private:
  bool online_=false, trying_=false;
  uint32_t failures_=0, attempts_=0, deadline_=0;
};
