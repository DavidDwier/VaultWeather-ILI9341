#pragma once
#include <stdint.h>
// Artwork indices follow user's numbered set 1..10 (zero-based here).
inline uint8_t weatherScene(int code, bool day) {
  if (code == 0) return day ? 0 : 1;
  if (code == 1 || code == 2) return day ? 2 : 3;
  if (code == 3) return 4;
  if (code == 45 || code == 48) return 9;
  if ((code >= 51 && code <= 57)) return 5;
  if (code == 61 || code == 63 || code == 65 || code == 66 || code == 67 ||
      code == 80 || code == 81 || code == 82) return 6;
  if (code == 71 || code == 73 || code == 75 || code == 77 || code == 85 || code == 86) return 7;
  if (code == 95 || code == 96 || code == 99) return 8;
  return 4; // Unknown: neutral cloud artwork, with explicit UNKNOWN label.
}
inline const char* weatherLabel(int code, bool day) {
  switch (code) {
    case 0: return day ? "SUNNY" : "CLEAR NIGHT";
    case 1: return "MAINLY CLEAR";
    case 2: return "PARTLY CLOUDY";
    case 3: return "OVERCAST";
    case 45: return "FOG";
    case 48: return "ICY FOG";
    case 51: return "LIGHT DRIZZLE";
    case 53: return "DRIZZLE";
    case 55: return "HEAVY DRIZZLE";
    case 56: case 57: return "ICY DRIZZLE";
    case 61: return "LIGHT RAIN";
    case 63: return "RAIN";
    case 65: return "HEAVY RAIN";
    case 66: case 67: return "FREEZING RAIN";
    case 71: return "LIGHT SNOW";
    case 73: return "SNOW";
    case 75: return "HEAVY SNOW";
    case 77: return "SNOW GRAINS";
    case 80: case 81: case 82: return "RAIN SHOWERS";
    case 85: case 86: return "SNOW SHOWERS";
    case 95: return "THUNDERSTORM";
    case 96: case 99: return "STORM / HAIL";
    default: return "UNKNOWN";
  }
}
