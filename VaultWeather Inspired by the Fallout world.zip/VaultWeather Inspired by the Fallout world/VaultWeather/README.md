# VaultWeather — GitHub edition

ESP32-C3 SuperMini weather station with a 2.0-inch ST7789 SPI display.
Ten supplied technician scenes, a live clock and Open-Meteo readings.
One fixed character pose per condition; only weather effects animate.

Open **FalloutWeather_C3/FalloutWeather_C3.ino** in Arduino IDE. The historical
sketch name is retained so the folder and main file match. This package is a
separate edition. See **START_HERE.txt** for the exact board, libraries, wiring,
WiFi setup and upload steps.

- ESP32 core **3.3.11**, ESP32C3 Dev Module, 4 MB, **Huge APP**, USB CDC enabled.
- Approved 320 × 240 PNGs are included unchanged under `artwork/weather/`.
  Firmware embeds their RGB565 representation; there is no resizing, palette
  reduction, dithering or character animation. Shared frame/right-side pixels
  reduce the artwork payload to 746,034 bytes without reducing RGB565 detail.
- The right glass holds city, clock, large temperature, exact condition label,
  feels like, humidity, wind, live/stale/offline status, data time and attribution.
- Weather effects stay within the left glass. Each tile is restored before
  compositing and sent complete; no intermediate blank frame is displayed.
- London is the public example. Set city, coordinates and local time rule
  together in `config.h`. Leave WiFi values blank to reuse phone-saved settings.
- The baseline's WiFi portal, NVS namespace/legacy keys, retry/recovery logic,
  HTTPS CA bundle, ten-minute refresh and day/night mapping are retained.
- `DEMO_MODE` is **false**. Optional demo mode cycles all ten correctly labelled
  scenes, eight seconds each, with clearly marked sample readings and no WiFi.
  `ANIMATION_ENABLED=false` disables effects while keeping weather/clock updates.

No sensor, SD card, filesystem upload, image decoder or API key is required.
Scheduled character routines and their assets have been removed.

## Verification

The release was compiled with the exact settings above. See
`docs/BUILD_VERIFICATION.txt` for measured flash/RAM, checks and physical tests
still required. `docs/native_scenes.png` shows host-rendered native-resolution
layouts with labelled sample data; it is not a photograph of the station.

To reproduce the build with Arduino CLI after installing the listed libraries:

```sh
arduino-cli core install esp32:esp32@3.3.11
arduino-cli compile --fqbn esp32:esp32:esp32c3:PartitionScheme=huge_app,CDCOnBoot=cdc,FlashSize=4M,EraseFlash=none FalloutWeather_C3
```

The Espressif Boards Manager index is
https://espressif.github.io/arduino-esp32/package_esp32_index.json

The firmware already includes the artwork. Only maintainers changing source
artwork need Python 3 and Pillow to run `python tools/pack_art.py`. That script
checks every reconstructed TFT pixel and regenerates the embedded header.
`artwork/SHA256SUMS.txt` records the unchanged source PNGs.

Weather data: https://open-meteo.com/ — displayed attribution: OPEN-METEO.
This archive has not been published to GitHub.
