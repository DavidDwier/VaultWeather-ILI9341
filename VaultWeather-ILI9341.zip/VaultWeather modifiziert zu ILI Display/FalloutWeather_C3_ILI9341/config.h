#pragma once
// OPTIONAL fallback: a nonempty WIFI_SSID below overrides saved phone settings.
// Leave both blank to reuse your existing saved Wi-Fi automatically.
#define WIFI_SSID ""
#define WIFI_PASSWORD ""
#define TFT_SCLK 1
#define TFT_MOSI 6
#define TFT_RST 3
#define TFT_DC 21
#define TFT_CS 7
#define TFT_ROTATION 3  // Rotated 180 degrees from the original orientation 1.
#define TFT_INVERT true
#define TFT_SPI_HZ 20000000
// Public example. Replace the label and coordinates with your location.
#define WEATHER_CITY "Berlin"
#define WEATHER_LAT 52.5188
#define WEATHER_LON 13.4083
// POSIX rule for the display clock (UK default).
#define LOCAL_TZ "CET-1CEST,M3.5.0,M10.5.0/3"
#define WEATHER_REFRESH_MS (10UL * 60UL * 1000UL)
#define ANIMATION_ENABLED true
#define DEMO_MODE false   // true: cycle ten scenes; sample numbers, no internet.
#define SETUP_AP_PASSWORD "vaultweather"
